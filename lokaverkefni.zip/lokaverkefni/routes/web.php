<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/blogs', 'PostsController@index');
Route::get('/blogs/create', 'PostsController@create')->middleware('auth');
Route::get('/blogs/{blog}', 'PostsController@show');
Route::post('/blogs', 'PostsController@store')->middleware('auth');
Route::get('/blogs/{blog}/edit', 'PostsController@edit')->middleware('auth');
Route::patch('/blogs/{blog}', 'PostsController@update')->middleware('auth');
Route::get('/blogs/user/{user}', 'PostsController@index');
Route::delete('/blogs/{blog}', 'PostsController@destroy')->middleware('auth');