@extends('layouts/app')

@section('content')
	<div class="row justify-content-center">
        @guest
		<h1>Blogs</h1>
        @else
        <h1>Your Blogs</h1>
        @endguest
	</div>
	<div class="row justify-content-center">
		<div class="w-50 justify-content-between">
    		@foreach($blogs as $blog)
                
    			<div class="card row justify-content-center bg-dark text-white">
                    
        			<h3 class="card-header"><a href="/blogs/{{ $blog->id }}">{{ $blog->title }}</a></h3>
        			<p class="card-body">{{ $blog->body }}</p>
                    <h6 class="card-subtitle p-3">DisBlogger: <a href="/blogs/user/{{ $blog->user->id }}">{{ $blog->user->name }}</a></h5>
                    @can('update', $blog)
                    <a class="btn btn-primary w-25" href="/blogs/{{ $blog->id }}/edit">Edit</a>
                    <form method="POST" action="{{ $blog->path() }}">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger w-25">Delete</button>
                    </form>
                    @endcan
        		</div>
    		@endforeach
    	</div>
    </div>
@endsection