@extends('layouts/app')

@section('content')
	<div class="row justify-content-center">
		<div class="w-50 h-120 justify-content-between card bg-dark text-white">
			<h6 class="card-subtitle p-3">DisBlogger: <a href="/blogs/user/{{ $blog->user->id }}">{{ $blog->user->name }}</a></h6>
			@can('update', $blog)
                    <a class="btn btn-primary w-25" href="/blogs/{{ $blog->id }}/edit">Edit</a>
                    <form method="POST" action="{{ $blog->path() }}">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger w-25">Delete</button>
                </form>
            @endcan
			<h1 class="card-header">{{ $blog->title }}</h1>
			<p class="card-body">{{ $blog->body }}</p>
		</div>
	</div>
@endsection