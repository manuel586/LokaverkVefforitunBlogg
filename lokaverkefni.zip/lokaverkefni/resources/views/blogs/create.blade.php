@extends('layouts/app')

@section('title', 'Create')

@section('content')
	
	@if ($errors->any())
    	<div class="alert alert-danger">
        	<ul>
            	@foreach ($errors->all() as $error)
                	<li>{{ $error }}</li>
            	@endforeach
        	</ul>
    	</div>
	@endif
	<form method="POST" action="/blogs">
		@csrf
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Title1">Title</label>
			<input type="text" name="title" class="form-control" value="{{ old('title') }}" id="Title1" placeholder="Title">
		</div>
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Bod1">Body</label>
			<textarea class="form-control" name="body" id="Bod1" rows="6">{{ old('body') }}</textarea>
		</div>
		<div class="form-group">
			<button class="btn btn-dark">Create</button>
		</div>
	</form>
@endsection