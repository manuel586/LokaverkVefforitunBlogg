@extends('layouts/app')

@section('title', 'Edit')

@section('content')
	<form method="POST" action="{{ $blog->path() }}">
		@csrf
		@method('patch')
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Title1">Title</label>
			<input type="title" name="title" class="form-control" value="{{ $blog->title }}" id="Title1" placeholder="Title">
		</div>
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Bod1">Body</label>
			<textarea class="form-control" name="body" id="Bod1" rows="6">{{ $blog->body }}</textarea>
		</div>
		<div class="form-group">
			<button class="btn btn-primary">Edit</button>
		</div>
	</form>
@endsection