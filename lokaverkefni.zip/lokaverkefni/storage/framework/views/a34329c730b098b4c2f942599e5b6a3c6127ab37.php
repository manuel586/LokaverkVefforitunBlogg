<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center">
        <?php if(auth()->guard()->guest()): ?>
		<h1>Blogs</h1>
        <?php else: ?>
        <h1>Your Blogs</h1>
        <?php endif; ?>
	</div>
	<div class="row justify-content-center">
		<div class="w-50 justify-content-between">
    		<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
    			<div class="card row justify-content-center bg-dark text-white">
                    
        			<h3 class="card-header"><a href="/blogs/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a></h3>
        			<p class="card-body"><?php echo e($blog->body); ?></p>
                    <h6 class="card-subtitle p-3">DisBlogger: <a href="/blogs/user/<?php echo e($blog->user->id); ?>"><?php echo e($blog->user->name); ?></a></h5>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $blog)): ?>
                    <a class="btn btn-primary w-25" href="/blogs/<?php echo e($blog->id); ?>/edit">Edit</a>
                    <form method="POST" action="<?php echo e($blog->path()); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger w-25">Delete</button>
                    </form>
                    <?php endif; ?>
        		</div>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>