<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center">
		<div class="w-50 h-120 justify-content-between card bg-dark text-white">
			<h6 class="card-subtitle p-3">DisBlogger: <a href="/blogs/user/<?php echo e($blog->user->id); ?>"><?php echo e($blog->user->name); ?></a></h6>
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $blog)): ?>
                    <a class="btn btn-primary w-25" href="/blogs/<?php echo e($blog->id); ?>/edit">Edit</a>
                    <form method="POST" action="<?php echo e($blog->path()); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger w-25">Delete</button>
                </form>
            <?php endif; ?>
			<h1 class="card-header"><?php echo e($blog->title); ?></h1>
			<p class="card-body"><?php echo e($blog->body); ?></p>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>