<?php $__env->startSection('title', 'Create'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if($errors->any()): ?>
    	<div class="alert alert-danger">
        	<ul>
            	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<li><?php echo e($error); ?></li>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	</ul>
    	</div>
	<?php endif; ?>
	<form method="POST" action="/blogs">
		<?php echo csrf_field(); ?>
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Title1">Title</label>
			<input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" id="Title1" placeholder="Title">
		</div>
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Bod1">Body</label>
			<textarea class="form-control" name="body" id="Bod1" rows="6"><?php echo e(old('body')); ?></textarea>
		</div>
		<div class="form-group">
			<button class="btn btn-dark">Create</button>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>