<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('content'); ?>
	<form method="POST" action="<?php echo e($blog->path()); ?>">
		<?php echo csrf_field(); ?>
		<?php echo method_field('patch'); ?>
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Title1">Title</label>
			<input type="title" name="title" class="form-control" value="<?php echo e($blog->title); ?>" id="Title1" placeholder="Title">
		</div>
		<div class="form-group bg-dark text-white p-3 mb-4 w-50">
			<label for="Bod1">Body</label>
			<textarea class="form-control" name="body" id="Bod1" rows="6"><?php echo e($blog->body); ?></textarea>
		</div>
		<div class="form-group">
			<button class="btn btn-primary">Edit</button>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>