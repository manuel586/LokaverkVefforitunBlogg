<?php $__env->startSection('content'); ?>
<h1 class="row justify-content-center">MaBlogg</h1>
<?php if(auth()->guard()->guest()): ?>
<div class="container card bg-dark">
    <div class="">
        <h2 class="p-3 mb-2 row justify-content-center bg-dark text-white">Ahoy thar!</h2>
    </div>
    <div class="">
        <p class="p-3 mb-2 bg-white rounded row justify-content-center">Welcome to MaBlogg! Register now to start blogging about whatever the hell you want to blog about.</p>
    </div>
</div>
<?php else: ?>
<div class="container card bg-dark">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="">
                <div class="p-3 mb-2 row justify-content-center bg-dark text-white">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <p>You are now logged in, please start blogging!</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>